<?php
/*
Plugin Name: Hello World
Plugin URI: nety
Author: Ivan Gaidar
Author URI: nety
*/
$hello_world = "Hello, world! Возможно я не правильно понял суть задания, что то нужно было делать с базой данных ? ";



function hello_world($title) {
	global $hello_world;

	echo $title.' -> '.$hello_world;
}

add_filter('the_title', 'hello_world');


?>